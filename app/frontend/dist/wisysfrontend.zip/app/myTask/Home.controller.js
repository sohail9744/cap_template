"use strict";sap.ui.define(["sap/ui/core/mvc/Controller"],function(e){"use strict";const t=e.extend("wisys.frontend.controller.Home",{});return t});
//# sourceMappingURL=Home.controller.js.map