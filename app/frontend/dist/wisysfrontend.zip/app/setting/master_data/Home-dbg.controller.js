"use strict";

sap.ui.define(["sap/ui/core/mvc/Controller"], function (Controller) {
  "use strict";

  /**
   * @namespace wisys.frontend.controller
   */
  const Home = Controller.extend("wisys.frontend.controller.Home", {});
  return Home;
});
//# sourceMappingURL=Home-dbg.controller.js.map
