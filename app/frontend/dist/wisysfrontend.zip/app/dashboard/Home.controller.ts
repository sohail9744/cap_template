import Controller from "sap/ui/core/mvc/Controller";


/**
 * @namespace wisys.frontend.controller
 */
export default class Home extends Controller {}
