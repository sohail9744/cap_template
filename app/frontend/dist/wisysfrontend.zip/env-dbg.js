"use strict";

sap.ui.define([], function () {
  "use strict";

  const confidential = () => ({
    AppId: "3",
    mockEmail: "xyz@tyyy.com.sa",
    production: false
  });
  const getConfidentialInfo = confidential;
  var __exports = {
    __esModule: true
  };
  __exports.getConfidentialInfo = getConfidentialInfo;
  return __exports;
});
//# sourceMappingURL=env-dbg.js.map
