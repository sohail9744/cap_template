import Controller from "sap/ui/core/mvc/Controller";

/**
 * @namespace wisys.dashboard.controller.Error
 */
export default class Error extends Controller {}