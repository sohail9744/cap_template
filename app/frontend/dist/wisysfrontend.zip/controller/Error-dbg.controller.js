"use strict";

sap.ui.define(["sap/ui/core/mvc/Controller"], function (Controller) {
  "use strict";

  /**
   * @namespace wisys.dashboard.controller.Error
   */
  const Error = Controller.extend("wisys.dashboard.controller.Error.Error", {});
  return Error;
});
//# sourceMappingURL=Error-dbg.controller.js.map
